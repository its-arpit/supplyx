
<?php include"header.php";?>
<html>
<head>
<title>Send Email | <?=$settings['app_name']?> - Dashboard</title>
</head>
</body>
      <!-- Content Wrapper. Contains page content -->
      <div class="content-wrapper">
        <?php include"public/email-send.php"; ?>
      </div><!-- /.content-wrapper -->
  </body>
</html>
<?php include"footer.php";?>
    		
